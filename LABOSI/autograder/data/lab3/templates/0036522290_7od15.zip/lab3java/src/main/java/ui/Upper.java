package ui;

public class Upper {
    public Upper() {
        
    }
}
