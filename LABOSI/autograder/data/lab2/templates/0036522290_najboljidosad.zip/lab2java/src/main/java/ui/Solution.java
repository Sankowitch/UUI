package ui;

import java.io.File;  
import java.io.FileNotFoundException;  
import java.util.*;

public class Solution {
    public static boolean nasliNil = false;  //korisitm
	public static LinkedHashMap<String, String> rezolvente = new LinkedHashMap<>();
	public static LinkedHashMap<String, Set<Integer>> pomoc = new LinkedHashMap<>();
	public static HashMap<Integer, String> iskoristeneRez = new HashMap<>();
	public static LinkedHashSet<Set<String>> setOfSupport = new LinkedHashSet<>();  //koristim
	public static LinkedHashSet<Set<String>> allClauses = new LinkedHashSet<>();    //koristim
	public static LinkedHashMap<String, String> nastanakRezolventi = new LinkedHashMap<>();
	
	public static void main(String ... args) {
		int ind = 0;
		boolean res=false;
		String putanja="";

		//ucitaj iz retka
		for(String a : args) {
			if (a.equals("resolution")) {
				res= true;
			} if (ind==1) {
				putanja = a;
			}
			ind = ind + 1;

		}

		//ucitaavanje klauzula
		Set<Set<String>> pocetne = new LinkedHashSet<>();
		
		LinkedHashSet<String> konacno = new LinkedHashSet<>();
		LinkedHashSet<String> pocetnaZaP = new LinkedHashSet<>();   //upisujemo string pocetnih funckija za prinntati jer mi se ne da iterirati kasnije
		String stringKlauzula="";
		try {
			File myObj = new File(putanja);
			Scanner myReader = new Scanner(myObj, "utf-8");
			ind = 0;
			boolean zadnja = false;
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
				data =  data.toLowerCase();
				stringKlauzula = data;
				
				String[] pomoc = data.split(" v ");

				TreeSet<String> klauzula = new TreeSet<>();

				if (data.contains("#")) {
					continue;
				} if (!myReader.hasNextLine()) {
                    zadnja = true;
					String nova="";
					for (String s: pomoc) {
						klauzula.clear();
                        if (s.contains("~")) {
                            nova = s.replaceAll("~", "");
						} else {
							nova = "~" + s;
						}
						klauzula.add(nova);
						pocetnaZaP.add(nova);
						setOfSupport.add(klauzula);
						konacno.addAll(klauzula);
						//allClauses.add(klauzula);

					}
					break;
				}
			
				for (String s : pomoc) {
					klauzula.add(s);
				}
				pocetnaZaP.add(stringKlauzula);
				allClauses.add(klauzula);
			    pocetne.add(klauzula);

			}
			myReader.close();

		} catch (FileNotFoundException e) {
			System.out.println("KOJI F U CHATU.");
			e.printStackTrace();
		  } 


		

		if (res==true) {
			
			 
			 //resolve(pocetne);
			 resolution(pocetne);
			 print(pocetnaZaP,stringKlauzula);
			 //printanje(pocetnaZaP, stringKlauzula);
			 
			 
		}
	}

    public static void reallyJan() {
		Set<String> novaK = new TreeSet<>();
		Set<Set<String>> newKlauzule = new LinkedHashSet<>();
		String negacija="";
		
		for (Set<String> set1 : allClauses) {
			for (Set<String> set2 : allClauses) {
				for (String s: set1) {
					if (s.contains("~")) {
						//s je negiran
						negacija = s.replace("~", "");
					} else {
						//s nije negiran
						negacija = "~" + s;
					}	

					novaK= nadiKlauzule(s, negacija, set1, set2);
					if (novaK.isEmpty()) {
						if (nasliNil == true) {
							return;
						}
						continue;
					}
					newKlauzule.add(novaK);
				}
			}
		}
		if (!newKlauzule.isEmpty()) {
            setOfSupport.addAll(newKlauzule);
		}
		
        allClauses.addAll(setOfSupport);
	}




	public static void resolution(Set<Set<String>> pocetne) {
        Set<String> novaK = new TreeSet<>();
		Set<Set<String>> newKlauzule = new LinkedHashSet<>();   //nova
        reallyJan();
		if (nasliNil == true) {
			return;
		}
  
		pocetak:
		while(true) {
			int iteracija1 = pocetne.size() + 1;
		    int iteracija2 = 1;
			String negacija="";
			for (Set<String> set1 : setOfSupport) {    //neka prodje kroz pocetne prvo
                iteracija2 = 1;
				for (Set<String> set2 : allClauses) {
					for (String s: set1) {
						if (s.contains("~")) {
							//s je negiran
							negacija = s.replace("~", "");
						} else {
							//s nije negiran
							negacija = "~" + s;
						}
						//novaK=provjeriKlauzule(s, negacija, set1, set2, iteracija1, iteracija2);
						novaK= nadiKlauzule(s, negacija, set1, set2);
						if (novaK.isEmpty()) {
							if (nasliNil == true) {
								break pocetak;
							}
							continue;
						}
						newKlauzule.add(novaK);
					}

                    iteracija2 = iteracija2 + 1;
				}
				iteracija1 = iteracija1 + 1;
            } 
			if (allClauses.containsAll(newKlauzule)) {
				break;
			}

			allClauses.addAll(newKlauzule);
			setOfSupport.addAll(newKlauzule);
			
		} 

	}







	//dobro je
	public static boolean provjeriTautologiju(Set<String> set) {
		for (String s : set) {
			String negacija = "~" + s;
			if (s.contains("~")) {
				negacija= s.replace("~", "");
			}
			if (set.contains(negacija)) {
                //pronasli smo tautologiju
				return true;
			}
		}
		return false;
	}

 
    //kako bi dobili klauzulu u stringu
    public static String stringZaRez(Set<String> set) {
		String rez="";
		int i = 0;
		for (String var: set) {
			rez = rez + var;
			if (i <= set.size() - 2) {
				rez = rez + " v ";
			}
			i = i + 1;
			
		}
		return rez;

	}

	
	public static void print(Set<String> ulazneKlauzule, String nuznaKlauzula) {  //nuzna je ona koju dokazujemo
        
		//ulazne klauzule
		int index = 1;
		for (String s : ulazneKlauzule) {
			System.out.println( String.valueOf(index)  + ". " +s);
			++index;
		}
		System.out.println("===============");

		//izvedene klauzule
		for (String djete : nastanakRezolventi.keySet()) {
			System.out.println(String.valueOf(index) +  ". "  + djete + " (" + nastanakRezolventi.get(djete) + ")" );
			++index;
		}
		System.out.println("===============");
        String konacniIspis = "[CONCLUSION]: " + nuznaKlauzula;
		if (nasliNil == true) {
			System.out.println(konacniIspis + " is true");
		} else {
			System.out.println(konacniIspis + " is unknown");
		}



	}
	
	



	public static Set<String> nadiKlauzule(String s, String negacija, Set<String> set1, Set<String> set2) {
        Set<String> novaK = new TreeSet<>();
		if (set2.contains(s)) {
			//apsorpcija
			//System.out.println("apsorpcijaaaa");
			return novaK;			
		} 
		if (set2.contains(negacija)) {
			String rezolventa = "";
			String roditelj1 = stringZaRez(set1);
			String roditelj2 = stringZaRez(set2);
			if (set1.size() == 1 && set2.size() == 1) {
                nasliNil = true;
				rezolventa = "NIL";
			} else {
				novaK.addAll(set1);
				novaK.addAll(set2);
				novaK.remove(s);
				novaK.remove(negacija);
				if (set1.size() > 1 && set2.size() > 1) {
					if (set1.size() == set2.size()) {
						if (!(novaK.size() == set1.size() - 1)) {
                            novaK.clear();
							return novaK;
						}
					} else {
						novaK.clear();
						return novaK;
					}
				}

				if (provjeriTautologiju(novaK)) {
                    novaK.clear();
					return novaK;
				}

				rezolventa = stringZaRez(novaK);
			}
			if (!nastanakRezolventi.containsKey(rezolventa)) {
				nastanakRezolventi.put(rezolventa, "(" + roditelj1 + ", " + roditelj2 + ")");
			}
		}



		return novaK;
	}

	

	public static void printanje(Set<String> pocetna, String konacniString) {
		String con = "[CONCLUSION]: " + konacniString;


		if (nasliNil == false) {
			int ji = 1;
			for (String st : pocetna) {
				System.out.println(String.valueOf(ji)+". " +st);
				ji = ji + 1;
			} 
			for (String bb : rezolvente.keySet()) {
                System.out.println(String.valueOf(ji) + bb + " " + rezolvente.get(bb));
				ji = ji + 1;
			}
            con = con + " is unknown";
			System.out.println(con);
			return;
		}
		con = con + " is true";
        //printanje pocetnih 
		int i = 1;
		for (String st : pocetna) {
            System.out.println(String.valueOf(i)+". " +st);
			i = i + 1;
		} 
		System.out.println("===============");
		for (String st : rezolvente.keySet()) {
			System.out.println(String.valueOf(i)+". " +st + " " + rezolvente.get(st));
			i = i + 1;
		}
		

		Set<Integer> kojeSmoKoristili = new TreeSet<>();
		Set<Integer> klauzula = pomoc.get("NIL");
		LinkedHashSet<Set<Integer>> klauzule = new LinkedHashSet<>();
		klauzule.add(klauzula);
        int broj = 0;
		//labelOne:
		//while(true) {
			
          //  for (Set<Integer> set : klauzule) {
				//broj = 0;
			//	for (int it : set ) {
                  //  if (it <= pocetna.size()) {
				//		broj = broj + 1;
					//}
					//if (iskoristeneRez.containsKey(it)) {
					//	klauzula = pomoc.get(iskoristeneRez.get(it));
					//	kojeSmoKoristili.add(it);
					//	klauzule.add(klauzula);
					//}
				//}
				//if (broj == 2) {
                  //  break labelOne;
				//}
			//}
			
            
		//}	
		
		for (int it : kojeSmoKoristili) {
			String rez = iskoristeneRez.get(it);
			System.out.println(String.valueOf(it) +". " + rez +" " + rezolvente.get(rez) );
		}
		System.out.println("NIL " + rezolvente.get("NIL"));

        System.out.println("===============");
		System.out.println(con);



	}

}