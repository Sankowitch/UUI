package ui;

import java.io.File;  
import java.io.FileNotFoundException;  
import java.util.*;

public class pomoc {
    public static boolean nasliNil = false;
	public static LinkedHashMap<String, String> rezolvente = new LinkedHashMap<>();
	public static LinkedHashMap<String, Set<Integer>> pomoc = new LinkedHashMap<>();
	public static HashMap<Integer, String> iskoristeneRez = new HashMap<>();
	public static LinkedHashSet<Set<String>> setOfSupport = new LinkedHashSet<>();
	public static LinkedHashSet<Set<String>> allClauses = new LinkedHashSet<>();
	
	public static void main(String ... args) {
		int ind = 0;
		boolean res=false;
		String putanja="";

		//ucitaj iz retka
		for(String a : args) {
			if (a.equals("resolution")) {
				res= true;
			} if (ind==1) {
				putanja = a;
			}
			ind = ind + 1;

		}

		//ucitaavanje klauzula
		Set<Set<String>> pocetne = new LinkedHashSet<>();
		Set<Set<String>> sos = new LinkedHashSet<>();
		LinkedHashSet<String> konacno = new LinkedHashSet<>();
		LinkedHashSet<String> pocetnaZaP = new LinkedHashSet<>();
		String nuzanUvijet="";
		try {
			File myObj = new File(putanja);
			Scanner myReader = new Scanner(myObj, "utf-8");
			ind = 0;
			boolean zadnja = false;
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
				data =  data.toLowerCase();
				nuzanUvijet = data;
				


				String[] pomoc = data.split(" v ");

				LinkedHashSet<String> klauzula = new LinkedHashSet<>();

				if (data.contains("#")) {
					continue;
				} if (!myReader.hasNextLine()) {
                    zadnja = true;
					String nova="";
					for (String s: pomoc) {
						klauzula.clear();
						if (s.contains("~")) {
                            nova = s.replaceAll("~", "");
						} else {
							nova = "~" + s;
						}
						klauzula.add(nova);
						pocetnaZaP.add(nova);
						sos.add(klauzula);
						setOfSupport.add(klauzula);
						konacno.addAll(klauzula);
						allClauses.add(klauzula);

					}
					break;
				}
			
				for (String s : pomoc) {
					klauzula.add(s);
				}
				pocetnaZaP.add(nuzanUvijet);
				allClauses.add(klauzula);
			    pocetne.add(klauzula);

			}
			myReader.close();

		} catch (FileNotFoundException e) {
			System.out.println("KOJI F U CHATU.");
			e.printStackTrace();
		  } 


		//System.out.println(res);
		//System.out.println(putanja);

		if (res==true) {
			 //resolution(pocetne, sos);
			 resolve(pocetne);
			 printanje(pocetnaZaP, konacno, nuzanUvijet);
			 
		}
	}

	public static void resolve(Set<Set<String>> pocetne) {
        Set<String> novaK = new LinkedHashSet<>();
		Set<Set<String>> svepomoc = new LinkedHashSet<>();   //nova

  
		label:
		while(true) {
			int iteracija1 = pocetne.size() + 1;
		    int iteracija2 = 1;
			
			for (Set<String> set1 : setOfSupport) {    //neka prodje kroz pocetne prvo
                
			    iteracija2 = 1;
				for (Set<String> set2 : allClauses) {

					for (String s: set1) {
						if (s.contains("~")) {
							//s je negiran
							String negacija = s.replace("~", "");
							novaK=provjeriKlauzule(s, negacija, set1, set2, iteracija1, iteracija2);
							
							if (novaK.isEmpty()) {
								if (nasliNil == true) {
                                    break label;
								}
								continue;
							}
							svepomoc.add(novaK);
							
								 
						} else {
							//s nije negiran
							String negacija = "~" + s;
							novaK=provjeriKlauzule(s, negacija, set1, set2, iteracija1, iteracija2);
							
							if (novaK.isEmpty()) {
								if (nasliNil == true) {
                                    
									break label;
								}
								continue;
							}
							
							svepomoc.add(novaK);
							

					    }

					}

                    iteracija2 = iteracija2 + 1;
				}
				iteracija1 = iteracija1 + 1;
               
			} 
			if (allClauses.containsAll(svepomoc)) {
				break;
			}

			allClauses.addAll(svepomoc);
			setOfSupport.addAll(svepomoc);
			
		} 

	}





	public static void resolution(Set<Set<String>> pocetne, Set<Set<String>> sosd) {
        Set<String> novaK = new LinkedHashSet<>();
		LinkedHashSet<Set<String>> sve = new LinkedHashSet<>();  //i pocetna i rez stanja
		Set<Set<String>> svepomoc = new LinkedHashSet<>();   //nova stanja
		LinkedHashSet<Set<String>> sos = new LinkedHashSet<>();
		sve.addAll(pocetne);
		sve.addAll(sosd);
		sos.addAll(sosd);
  
		label:
		while(true) {
			int iteracija1 = pocetne.size() + 1;
		    int iteracija2 = 1;
			//svepomoc.clear();
			for (Set<String> set1 : sos) {    //neka prodje kroz pocetne prvo
                
			    iteracija2 = 1;
				for (Set<String> set2 : sve) {

					for (String s: set1) {
						if (s.contains("~")) {
							//s je negiran
							String negacija = s.replace("~", "");
							novaK=provjeriKlauzule(s, negacija, set1, set2, iteracija1, iteracija2);
							
							if (novaK.isEmpty()) {
								if (nasliNil == true) {
                                    break label;
								}
								continue;
							}
							svepomoc.add(novaK);
							
								 
						} else {
							//s nije negiran
							String negacija = "~" + s;
							novaK=provjeriKlauzule(s, negacija, set1, set2, iteracija1, iteracija2);
							
							if (novaK.isEmpty()) {
								if (nasliNil == true) {
                                    
									break label;
								}
								continue;
							}
							
							svepomoc.add(novaK);
							

					    }

					}

                    iteracija2 = iteracija2 + 1;
				}
				iteracija1 = iteracija1 + 1;
               
			} 
			if (sve.containsAll(svepomoc)) {
				break;
			}

			sve.addAll(svepomoc);
			sos.addAll(svepomoc);
			
		} 
	}

	public static boolean checkNil(Set<String> set1, Set<String> set2) {
        if (set1.size() == 1 && set2.size() == 1) {
			return true;
		}
		return false;
	}

	public static boolean provjeriTautologiju(Set<String> set) {
		for (String s : set) {
			String negacija = "~" + s;
			if (s.contains("~")) {
				negacija= s.replace("~", "");
			}
			if (set.contains(negacija)) {
                //pronasli smo tautologiju
				return true;
			}
		}
		return false;
	}


	public static Set<String> provjeriKlauzule(String s, String negacija, Set<String> set1, Set<String> set2, int i1, int i2)  {
        Set<String> novaK = new LinkedHashSet<>();
		
		if (set2.contains(s)) {
			//apsorpcija
			//System.out.println("apsorpcijaaaa");
		} if (set2.contains(negacija)) {
			if (set1.size() > 1 && set2.size() > 1) {
				return novaK;
			}
			String rezolventa = "";
			if (checkNil(set1, set2) == true) {
				//nasli nil
				nasliNil = true;
				rezolventa = "NIL";
				
				
			} else {
			
			    novaK.addAll(set1);
			    novaK.addAll(set2);
			    novaK.remove(s);
			    novaK.remove(negacija);
			
			    if (provjeriTautologiju(novaK) == true) {
				    novaK.clear();
				    System.out.println("TAUTOLOGIJA");
				    return novaK;
			    }
				int i = 0;
				for (String var: novaK) {
					rezolventa = rezolventa + var;
					if (i <= novaK.size() - 2) {
                        rezolventa = rezolventa + " v ";
					}
					i = i + 1;
                    
				}
			}
			String koraci = "(" + String.valueOf(i2) +"," + String.valueOf(i1)+ ")";
			if (!rezolvente.containsKey(rezolventa)) {
				rezolvente.put(rezolventa, koraci);
				HashSet<Integer> redni = new HashSet<>();
				redni.add(i1);
				redni.add(i2);
				pomoc.put(rezolventa, redni);
			} 
			if (!iskoristeneRez.containsKey(i1+1)) {
                iskoristeneRez.put(i1 + 1, rezolventa);
			}
			

		}
		return novaK;
	}

	public static void printanje(Set<String> pocetna,Set<String> konacno, String konacniString) {
		String con = "[CONCLUSION]: " + konacniString;


		if (nasliNil == false) {
			int ji = 1;
			for (String st : pocetna) {
				System.out.println(String.valueOf(ji)+". " +st);
				ji = ji + 1;
			} 
			for (String bb : rezolvente.keySet()) {
                System.out.println(String.valueOf(ji) + bb + " " + rezolvente.get(bb));
				ji = ji + 1;
			}
            con = con + " is unknown";
			System.out.println(con);
			return;
		}
		con = con + " is true";
        //printanje pocetnih 
		int i = 1;
		for (String st : pocetna) {
            System.out.println(String.valueOf(i)+". " +st);
			i = i + 1;
		} 
		System.out.println("===============");
		for (String st : rezolvente.keySet()) {
			System.out.println(String.valueOf(i)+". " +st + " " + rezolvente.get(st));
			i = i + 1;
		}
		

		Set<Integer> kojeSmoKoristili = new TreeSet<>();
		Set<Integer> klauzula = pomoc.get("NIL");
		LinkedHashSet<Set<Integer>> klauzule = new LinkedHashSet<>();
		klauzule.add(klauzula);
        int broj = 0;
		//labelOne:
		//while(true) {
			
          //  for (Set<Integer> set : klauzule) {
				//broj = 0;
			//	for (int it : set ) {
                  //  if (it <= pocetna.size()) {
				//		broj = broj + 1;
					//}
					//if (iskoristeneRez.containsKey(it)) {
					//	klauzula = pomoc.get(iskoristeneRez.get(it));
					//	kojeSmoKoristili.add(it);
					//	klauzule.add(klauzula);
					//}
				//}
				//if (broj == 2) {
                  //  break labelOne;
				//}
			//}
			
            
		//}	
		
		for (int it : kojeSmoKoristili) {
			String rez = iskoristeneRez.get(it);
			System.out.println(String.valueOf(it) +". " + rez +" " + rezolvente.get(rez) );
		}
		System.out.println("NIL " + rezolvente.get("NIL"));

        System.out.println("===============");
		System.out.println(con);



	}

}